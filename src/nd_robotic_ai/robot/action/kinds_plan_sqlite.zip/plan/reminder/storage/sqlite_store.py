from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import date
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional

import yaml

from nd_robotic_ai.robot.action.kinds.children import Child
from nd_robotic_ai.robot.action.kinds.core.kind import Kind
from nd_robotic_ai.robot.action.kinds.core.yaml_kinds_loader import YamlKindsLoader
from nd_robotic_ai.robot.action.plan.reminder.schedule.by_date_time_loader import ByDateTimeLoader, ScheduledItem


class SQLitePlannerStore:
    def __init__(
        self,
        db_file_path: str,
        kinds_loader: Optional[YamlKindsLoader] = None,
        by_date_time_loader: Optional[ByDateTimeLoader] = None,
    ) -> None:
        self._db_path = Path(db_file_path).expanduser().resolve()
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._kinds_loader = kinds_loader
        self._by_date_time_loader = by_date_time_loader

        self._initialize_schema()

    def get_db_path(self) -> str:
        return str(self._db_path)

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(str(self._db_path))
        try:
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA foreign_keys = ON")
            yield connection
            connection.commit()
        finally:
            connection.close()

    def _initialize_schema(self) -> None:
        with self._connection() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS kinds (
                    title TEXT PRIMARY KEY,
                    position INTEGER NOT NULL
                );

                CREATE TABLE IF NOT EXISTS kind_children (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    kind_title TEXT NOT NULL,
                    position INTEGER NOT NULL,
                    title TEXT NOT NULL,
                    duration_seconds INTEGER NOT NULL,
                    FOREIGN KEY (kind_title) REFERENCES kinds(title) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS scheduled_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    day TEXT NOT NULL,
                    time_raw TEXT NOT NULL,
                    title TEXT NOT NULL,
                    detail TEXT NOT NULL DEFAULT '',
                    kind TEXT NOT NULL DEFAULT '',
                    children_titles_json TEXT NOT NULL DEFAULT '[]',
                    reminders_json TEXT NOT NULL DEFAULT '[]',
                    position INTEGER NOT NULL DEFAULT 0
                );

                CREATE UNIQUE INDEX IF NOT EXISTS idx_scheduled_day_time_title_position
                ON scheduled_items(day, time_raw, title, position);

                CREATE TABLE IF NOT EXISTS blobs (
                    key TEXT PRIMARY KEY,
                    value_json TEXT NOT NULL
                );
                """
            )

    def migrate_from_yaml_if_needed(
        self,
        yaml_kinds_file_path: Optional[str],
        yaml_plan_by_date_time_file_path: Optional[str],
        yaml_to_plan_file_path: Optional[str],
    ) -> None:
        self._migrate_kinds_if_needed(yaml_kinds_file_path)
        self._migrate_schedule_if_needed(yaml_plan_by_date_time_file_path)
        self._migrate_to_plan_if_needed(yaml_to_plan_file_path)

    def _table_is_empty(self, table_name: str) -> bool:
        with self._connection() as connection:
            row = connection.execute(f"SELECT COUNT(*) AS count_value FROM {table_name}").fetchone()
        return row is None or int(row["count_value"]) == 0

    def _migrate_kinds_if_needed(self, yaml_file_path: Optional[str]) -> None:
        if yaml_file_path is None or self._kinds_loader is None:
            return
        if not self._table_is_empty("kinds"):
            return

        path = Path(yaml_file_path)
        if not path.exists():
            return

        loaded = self._kinds_loader.load(str(path)).plans
        self.replace_kinds(loaded)

    def _migrate_schedule_if_needed(self, yaml_file_path: Optional[str]) -> None:
        if yaml_file_path is None or self._by_date_time_loader is None:
            return
        if not self._table_is_empty("scheduled_items"):
            return

        path = Path(yaml_file_path)
        if not path.exists():
            return

        items_by_day, _raw = self._by_date_time_loader.load(str(path))
        scheduled_items: List[ScheduledItem] = []
        for day_value in sorted(items_by_day.keys()):
            scheduled_items.extend(items_by_day[day_value])
        self.replace_scheduled_items(scheduled_items)

    def _migrate_to_plan_if_needed(self, yaml_file_path: Optional[str]) -> None:
        if yaml_file_path is None:
            return
        if self.get_blob("to_plan") is not None:
            return

        path = Path(yaml_file_path)
        if not path.exists():
            return

        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
        if raw is None:
            return
        if not isinstance(raw, dict):
            raw = {"_root": raw}
        self.set_blob("to_plan", raw)

    def load_kinds(self) -> List[Kind]:
        with self._connection() as connection:
            kind_rows = connection.execute(
                "SELECT title, position FROM kinds ORDER BY position ASC, title ASC"
            ).fetchall()

            child_rows = connection.execute(
                "SELECT kind_title, title, duration_seconds, position FROM kind_children "
                "ORDER BY kind_title ASC, position ASC, id ASC"
            ).fetchall()

        children_by_kind: Dict[str, List[Child]] = {}
        for row in child_rows:
            children_by_kind.setdefault(str(row["kind_title"]), []).append(
                Child(
                    title=str(row["title"]),
                    duration_seconds=int(row["duration_seconds"]),
                )
            )

        return [
            Kind(title=str(row["title"]), children=children_by_kind.get(str(row["title"]), []))
            for row in kind_rows
        ]

    def replace_kinds(self, kinds: List[Kind]) -> None:
        with self._connection() as connection:
            connection.execute("DELETE FROM kind_children")
            connection.execute("DELETE FROM kinds")

            for kind_position, kind in enumerate(kinds):
                connection.execute(
                    "INSERT INTO kinds(title, position) VALUES(?, ?)",
                    (kind.title, kind_position),
                )
                for child_position, child in enumerate(kind.children):
                    connection.execute(
                        "INSERT INTO kind_children(kind_title, position, title, duration_seconds) VALUES(?, ?, ?, ?)",
                        (kind.title, child_position, child.title, int(child.duration_seconds)),
                    )

    def load_scheduled_items(self) -> Dict[date, List[ScheduledItem]]:
        with self._connection() as connection:
            rows = connection.execute(
                "SELECT * FROM scheduled_items ORDER BY day DESC, position ASC, id ASC"
            ).fetchall()

        items_by_day: Dict[date, List[ScheduledItem]] = {}
        for row in rows:
            day_value = date.fromisoformat(str(row["day"]))
            item = ScheduledItem(
                day=day_value,
                time_value=self._parse_time(str(row["time_raw"])),
                time_raw=str(row["time_raw"]),
                title=str(row["title"]),
                detail=str(row["detail"] or ""),
                kind=str(row["kind"] or ""),
                children_titles=self._parse_json_list(row["children_titles_json"]),
                reminders=self._parse_json_list(row["reminders_json"]),
            )
            items_by_day.setdefault(day_value, []).append(item)

        for day_value, items in items_by_day.items():
            items.sort(key=lambda item: self._sort_key(item.time_raw, item.title))
        return items_by_day

    def add_scheduled_item(self, target_day: date, title: str, time_raw: str) -> None:
        normalized_time = self._normalize_time_text(time_raw)
        next_position = self._next_position_for_day(target_day)
        with self._connection() as connection:
            connection.execute(
                "INSERT INTO scheduled_items(day, time_raw, title, position) VALUES(?, ?, ?, ?)",
                (target_day.isoformat(), normalized_time, title, next_position),
            )

    def move_scheduled_item(self, source_day: date, target_day: date, time_raw: str, title: str) -> None:
        row_id = self._find_scheduled_item_id(source_day, title, time_raw)
        if row_id is None:
            raise ValueError(f"Could not find task in source day: {title} at {time_raw} on {source_day.isoformat()}")

        normalized_time = self._normalize_time_text(time_raw)
        next_position = self._next_position_for_day(target_day)
        with self._connection() as connection:
            connection.execute(
                "UPDATE scheduled_items SET day = ?, time_raw = ?, position = ? WHERE id = ?",
                (target_day.isoformat(), normalized_time, next_position, row_id),
            )

    def delete_scheduled_item(self, source_day: date, title: str, time_raw: str) -> None:
        row_id = self._find_scheduled_item_id(source_day, title, time_raw)
        if row_id is None:
            raise ValueError(f"Could not find task to delete: {title} at {time_raw} on {source_day.isoformat()}")

        with self._connection() as connection:
            connection.execute("DELETE FROM scheduled_items WHERE id = ?", (row_id,))

    def edit_scheduled_item(
        self,
        source_day: date,
        source_title: str,
        source_time_raw: str,
        target_day: date,
        target_title: str,
        target_time_raw: str,
    ) -> None:
        row_id = self._find_scheduled_item_id(source_day, source_title, source_time_raw)
        if row_id is None:
            raise ValueError(
                f"Could not find task to edit: {source_title} at {source_time_raw} on {source_day.isoformat()}"
            )

        with self._connection() as connection:
            current_row = connection.execute(
                "SELECT * FROM scheduled_items WHERE id = ?",
                (row_id,),
            ).fetchone()
            if current_row is None:
                raise ValueError(
                    f"Could not find task to edit: {source_title} at {source_time_raw} on {source_day.isoformat()}"
                )

            new_position = int(current_row["position"])
            if source_day != target_day:
                new_position = self._next_position_for_day(target_day, connection=connection)

            connection.execute(
                "UPDATE scheduled_items SET day = ?, time_raw = ?, title = ?, position = ? WHERE id = ?",
                (
                    target_day.isoformat(),
                    self._normalize_time_text(target_time_raw),
                    target_title,
                    new_position,
                    row_id,
                ),
            )

    def get_blob(self, key: str) -> Optional[Any]:
        with self._connection() as connection:
            row = connection.execute("SELECT value_json FROM blobs WHERE key = ?", (key,)).fetchone()
        if row is None:
            return None
        return json.loads(str(row["value_json"]))

    def set_blob(self, key: str, value: Any) -> None:
        with self._connection() as connection:
            connection.execute(
                "INSERT INTO blobs(key, value_json) VALUES(?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value_json = excluded.value_json",
                (key, json.dumps(value, ensure_ascii=False)),
            )

    def _next_position_for_day(self, target_day: date, connection: Optional[sqlite3.Connection] = None) -> int:
        owns_connection = connection is None
        if owns_connection:
            connection_context = self._connection()
            connection = connection_context.__enter__()
        try:
            row = connection.execute(
                "SELECT COALESCE(MAX(position), -1) AS max_position FROM scheduled_items WHERE day = ?",
                (target_day.isoformat(),),
            ).fetchone()
            max_position = -1 if row is None else int(row["max_position"])
            return max_position + 1
        finally:
            if owns_connection:
                connection_context.__exit__(None, None, None)

    def _find_scheduled_item_id(self, source_day: date, title: str, time_raw: str) -> Optional[int]:
        normalized_time = self._normalize_time_text(time_raw)
        with self._connection() as connection:
            rows = connection.execute(
                "SELECT id, title, time_raw FROM scheduled_items WHERE day = ? ORDER BY position ASC, id ASC",
                (source_day.isoformat(),),
            ).fetchall()

        target_title = title.strip()
        for row in rows:
            if str(row["title"]).strip() == target_title and self._normalize_time_text(str(row["time_raw"])) == normalized_time:
                return int(row["id"])
        return None

    def _parse_json_list(self, value: Any) -> List[str]:
        try:
            parsed = json.loads(str(value))
        except Exception:
            return []
        if not isinstance(parsed, list):
            return []
        return [str(item) for item in parsed]

    def _parse_time(self, raw: str):
        if self._by_date_time_loader is None:
            return None
        return self._by_date_time_loader._parse_time(raw)

    def _normalize_time_text(self, text: str) -> str:
        value = str(text).strip().lower()
        if value in {"pending", "pernding", "unplanned", ""}:
            return "pending"
        return value

    def _sort_key(self, time_raw: str, title: str):
        normalized_time = str(time_raw).strip().lower()
        if normalized_time in {"pending", "pernding", "unplanned", ""}:
            return (1, 99, 99, title.lower())

        parts = normalized_time.split(":")
        if len(parts) != 2:
            return (1, 99, 99, title.lower())

        try:
            hour_value = int(parts[0])
            minute_value = int(parts[1])
            return (0, hour_value, minute_value, title.lower())
        except ValueError:
            return (1, 99, 99, title.lower())
